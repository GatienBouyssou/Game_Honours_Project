# jCOLIBRI
jCOLIBRI is an object-oriented framework in Java for building CBR systems
