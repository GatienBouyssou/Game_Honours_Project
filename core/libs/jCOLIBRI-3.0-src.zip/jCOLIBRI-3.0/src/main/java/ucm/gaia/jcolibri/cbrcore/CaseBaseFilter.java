package ucm.gaia.jcolibri.cbrcore;

/**
 * Filter to retrieve cases. This will be used in a future.
 * @author Juan A. Recio-García
 *
 */
public class CaseBaseFilter implements Filter
{

}
